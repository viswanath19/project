package com.capgemini.onlineBanking.dao;

import java.io.IOException;
import java.sql.SQLException;

import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.exception.onlineBankingException;

public interface IUserLogin {

	String LoginValidation(String userName, String pwd);

	String getRegistered(UserAccountBean useraccountbean) throws onlineBankingException;

	String getMiniStatement(long account) throws ClassNotFoundException, IOException, SQLException;

	boolean validatePayee(long account, long paccount);

	String transferFunds(long account, long paccount, int amount,String password);

	boolean updateEmail(UserAccountBean useraccountbean);

	boolean updateAddress(UserAccountBean useraccountbean);
	void blockAccount(String userName, String pwd);

	String getDetailedStatement(long account, String fromDate, String toDate);

	String raiseCheckBookRequest(long account);

}

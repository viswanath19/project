package com.capgemini.onlineBanking.exception;

public class onlineBankingException extends Exception{
	public onlineBankingException(String msg){
		super(msg);
	}
}

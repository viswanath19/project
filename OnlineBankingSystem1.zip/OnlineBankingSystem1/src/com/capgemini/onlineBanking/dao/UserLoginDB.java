package com.capgemini.onlineBanking.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.onlineBanking.Util.RechargeDBConnection;
import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.exception.onlineBankingException;

public class UserLoginDB implements IUserLogin {

	@Override
	public String LoginValidation(String userName, String pwd) {
		String password=null;
		String result = "false";
		String status=null;
		UserAccountBean rb=new UserAccountBean();
		long accountno;
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  
		//step2 create  the connection object  
		Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
		  
		//step3 create the statement object  
		Statement stmt=con.createStatement(); 
		Long user_id=Long.valueOf(userName);
		  
		//step4 execute query  
		ResultSet rs=stmt.executeQuery("select login_password,account_no,lock_status from user_table where user_id='"+user_id+"'"); 
		if(rs!=null){
			while(rs.next()){
				password=rs.getString(1);
				accountno=rs.getLong(2);
				status=rs.getString(3);
				//System.out.println(password);
				//System.out.println(pwd);
				if(password.equals(pwd)&&status.equals("U")){
					//rb.setAccNumber(accountno);
					result=String.valueOf(accountno);
					//System.out.println(result);
				}
				else{
					result="false";
					//System.out.println(result);
				}
				//sb.append(planname+"      "+Integer.toString(amount)+"\n");
				//System.out.println(details);
				
			}
		}
		//step5 close the connection object  
		con.close();  
		  
		}catch(Exception e){ 
			//msg=e.getMessage();
		}

		return result;
	}

	@Override
	public String getRegistered(UserAccountBean useraccountbean) throws onlineBankingException {
		String valuesInserted=null;
		try{
			//System.out.println("hello");
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			//System.out.println("hello");
			Connection con=RechargeDBConnection.getConnection();
			//System.out.println("hello");//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			String s1="insert into user_table values(?,?,?,?,?,?,?)";
			PreparedStatement s=con.prepareStatement(s1);
			//String s2="select rec_seq.nextval from dual";
			java.sql.Statement sw=con.createStatement();
			//ResultSet r1=sw.executeQuery(s2);
			//s.executeUpdate();
			
			s=con.prepareStatement(s1);
			//System.out.println("hello");
			
			//s.setInt(1,val);
			s.setLong(1,useraccountbean.getAccountNo());
			s.setLong(2,useraccountbean.getUserid());
			s.setString(3, useraccountbean.getLoginpassword());
			s.setString(4, useraccountbean.getSecurityQuestion());
			s.setString(5,useraccountbean.getTransPassword());
			s.setString(6, useraccountbean.getLockStatus());
		    s.setString(7,useraccountbean.getSecurityAnswer());
			//System.out.println(useraccountbean.getAccountNo());
			int result=s.executeUpdate();
			//System.out.println(result);
			if(result<0){
				throw new onlineBankingException("Please Create your Bank Account to opt online Banking");
			}
			else if(result>0){
				valuesInserted="true";
			}
			}
			catch(Exception e){
				throw new onlineBankingException("Please Create your Bank Account to opt online Banking");
			}
			return valuesInserted;
	}

	@Override
	public String getMiniStatement(long account) throws ClassNotFoundException, IOException, SQLException {
		String trans_date=null;
		long acc_no;
		long trans_id;
		StringBuilder sb=new StringBuilder();
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");   
		//step2 create  the connection object  
		Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
		Statement stmt=con.createStatement();  
		  
		//step4 execute query  
		ResultSet rs=stmt.executeQuery("select transaction_id,account_no,dateoftransaction from transactions where account_no='"+account+"' and rownum<=5"); 
		
		if(rs!=null){
			while(rs.next()){
				//account=rs.getLong(1);
			    trans_date=rs.getString(3);
			    trans_id=rs.getLong(1);
				acc_no=rs.getLong(2);
				sb.append(acc_no+"                   "+trans_id+"           "+trans_date+"\n");
			}
		}
		con.close();  
		  
	}catch(Exception e){ 
		//msg=e.getMessage();
	}
		// TODO Auto-generated method stub
		return sb.toString();
	}

	@Override
	public boolean validatePayee(long account, long paccount) {
		long payeraccount;
		int i=0;
		long paccounts[]=new long[100];
		boolean validatePayee=false;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			ResultSet rs=stmt.executeQuery("select payeeaccount_no from payee_table where account_no='"+account+"'"); 
			if(rs!=null){
				while(rs.next()){
					payeraccount=rs.getLong(1);
					paccounts[i++]=payeraccount;
				}
			}
			for(i=0;i<paccounts.length;i++){
			if(paccounts[i]==paccount){
				validatePayee=true;
			}
			}
			//System.out.println(sb);
			//step5 close the connection object  
			con.close();  
			  
			}catch(Exception e){ 
				//msg=e.getMessage();
			}
		return validatePayee;
	}

	@Override
	public String transferFunds(long account, long paccount, int amount,String password) {
		int userBalance=0;
		int payeeBalance=0;
		String pwd=null;
		String fundTransfer="false";
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			ResultSet resultset=stmt.executeQuery("select transaction_password from user_table where account_no='"+account+"'");
			if(resultset!=null){
				while(resultset.next()){
					pwd=resultset.getString(1);
				}
			}
			if(password.equals(pwd)){
			ResultSet rs=stmt.executeQuery("select account_balance from account_master where account_no='"+account+"'"); 
			if(rs!=null){
				while(rs.next()){
					userBalance=rs.getInt(1);
				}
			}
			ResultSet rs1=stmt.executeQuery("select account_balance from account_master where account_no='"+paccount+"'"); 
			if(rs1!=null){
				while(rs1.next()){
					payeeBalance=rs1.getInt(1);
				}
			}
			userBalance=userBalance-amount;
			payeeBalance=payeeBalance+amount;
			int userresult=stmt.executeUpdate("update account_master set account_balance='"+userBalance+"' where account_no='"+account+"'");
			int payeeresult=stmt.executeUpdate("update account_master set account_balance='"+payeeBalance+"' where account_no='"+paccount+"'");
			if(userresult>0&&payeeresult>0){
				fundTransfer="true";
			}
			else{
				fundTransfer="false";
			}
			}
			else{
				fundTransfer="Wrong Transaction Password";
			}
			con.close();  
		}
		catch(Exception e){
			
		}
		return fundTransfer;
	}

	@Override
	public boolean updateEmail(UserAccountBean useraccountbean) {
		boolean result = false;
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			
			//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			String s1="update customers set email = ? where account_no =?";
			PreparedStatement s=con.prepareStatement(s1);
			s.setString(1, useraccountbean.getEmail());
			s.setLong(2, useraccountbean.getAccountNo());
			//System.out.println("hello");
			int status=s.executeUpdate();
			//System.out.println("hello");
			if(status>0)
				result = true;
			else result = false;
			
			con.commit();
			con.close();
		}
		catch(Exception e){
			
		}
		return result;

	}

	@Override
	public boolean updateAddress(UserAccountBean useraccountbean) {
boolean result = false;
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			
			//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			String s1="update customers set address = ? where account_no = ?";
			PreparedStatement s=con.prepareStatement(s1);
			s.setString(1, useraccountbean.getAddress());
			s.setLong(2, useraccountbean.getAccountNo());
			int status=s.executeUpdate();
			if(status>0)
				result = true;
			else result = false;
			
			con.commit();
			con.close();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return result;
	
	}
	@Override
	public void blockAccount(String userName, String pwd) {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			//int rs=stmt.executeQuery("select account_no,login_password,lock_status from user_table where user_id='"+userName+"'"); 
			int rs=stmt.executeUpdate("Update user_table set lock_status='L' where user_id='"+userName+"'");
			/*if(rs>0){
				System.out.println("Account Blocked");
			}
			else{
				System.out.println("Failed to recognize user_id");
			}*/
			//step5 close the connection object  
			con.close();  
			  
			}catch(Exception e){ 
				//msg=e.getMessage();
			}
		
	}

	@Override
	public String getDetailedStatement(long account, String fromDate, String toDate) {
		StringBuilder sb=new StringBuilder();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			//int rs=stmt.executeQuery("select account_no,login_password,lock_status from user_table where user_id='"+userName+"'"); 
			//int rs=stmt.executeUpdate("Update user_table set lock_status='L' where user_id='"+userName+"'");
			//System.out.println("helo");
			ResultSet rs=stmt.executeQuery("select account_no,transaction_id,dateoftransaction from transactions where account_no='"+account+"' and dateoftransaction between '"+fromDate+"' and '"+toDate+"'");
			//System.out.println("hello");
			if(rs!=null){
				while(rs.next()){
					//System.out.println("hello");
					sb.append(rs.getString(1)+"                    "+rs.getString(2)+"                  "+rs.getString(3)+"\n");
				}
			}
			/*if(rs>0){
				System.out.println("Account Blocked");
			}
			else{
				System.out.println("Failed to recognize user_id");
			}*/
			//step5 close the connection object  
			con.close();  
			  
			}catch(Exception e){ 
				//msg=e.getMessage();
			}
		return sb.toString();

	}

	@Override
	public String raiseCheckBookRequest(long account) {
		long service_id=0;
		String service_request=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();
			String sql="insert into serviceTracker values(?,?,?,SYSDATE,?)";
			String seq_id="select service_seq_id.nextval from dual";
			ResultSet rs=stmt.executeQuery(seq_id);
			if(rs!=null){
				while(rs.next()){
					service_id=rs.getLong(1);
				}
			}
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setLong(1,service_id);
			ps.setString(2, "CheckBook");
			ps.setLong(3, account);
			ps.setString(4, "OpenState");
			int result=ps.executeUpdate();
			if(result>0){
				service_request=Long.toString(service_id);
			}
			else{
				service_request="failed to generate check book request";
			}
			
		}
		catch(Exception e){
			
		}
		return service_request;
	}


}


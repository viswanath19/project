package com.capgemini.onlineBanking.service;

import java.io.IOException;
import java.sql.SQLException;

import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.exception.onlineBankingException;

public interface IUserAccount {
	String isValidUser(String userName, String pwd);

	String getRegistered(UserAccountBean useraccountbean) throws onlineBankingException;

	String getMiniStatement(long account) throws ClassNotFoundException, IOException, SQLException;

	boolean validatePayee(long account, long paccount);

	String transferFund(long account, long paccount, int amount,String password);
	void blockAccount(String userName, String pwd);

	boolean updateEmail(UserAccountBean useraccountbean);

	boolean updateAddress(UserAccountBean useraccountbean);

	String getDetailedStatement(long account, String fromDate, String toDate);

	String raiseCheckBook(long account);
}
